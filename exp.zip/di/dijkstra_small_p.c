#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>


#define WORD_SIZE (4)

void write_word(void *mem, char *buf) {
memcpy(mem, buf, WORD_SIZE);
return;
}

void read_word(void *mem, char *buf) {
memcpy(buf, mem, WORD_SIZE);
return;
}

void pmem_write(void *mem, char *buf, int size) {
int cnt = (size + WORD_SIZE - 1) / WORD_SIZE;
for (int i=0; i<cnt; i++) {
int offset = i * WORD_SIZE;
write_word((char*)mem+offset, buf+offset);
}
return;
}

void pmem_read(void *mem, char *buf, int size) {
int cnt = (size + WORD_SIZE - 1) / WORD_SIZE;
for (int i=0; i<cnt; i++) {
int offset = i * WORD_SIZE;
read_word((char*)mem+offset, buf+offset);
}
return;
}


#define NUM_NODES                          100
#define NONE                               9999

struct _NODE
{
int iDist;
int iPrev;
};
typedef struct _NODE NODE;

struct _QITEM
{
int iNode;
int iDist;
int iPrev;
struct _QITEM *qNext;
};
typedef struct _QITEM QITEM;

QITEM *qHead = NULL;

    
long long NULL_INT = 0;
int NONE_INT = 9999;
int NUM_NODES_INT = 100;           
    
int **AdjMatrix;


int g_qCount = 0;
NODE *rgnNodes;
int ch;
int iPrev, iNode;
int i, iCost, iDist;


void print_path (NODE *rgnNodes, int chNode)
{
if (rgnNodes[chNode].iPrev != NONE)
{
print_path(rgnNodes, rgnNodes[chNode].iPrev);
}
printf (" %d", chNode);
fflush(stdout);
}

void enqueue (int iNode, int iDist, int iPrev)
{
QITEM *qNew = (QITEM *) malloc(sizeof(QITEM));
QITEM *qLast = qHead;

if (!qNew) 
{
fprintf(stderr, "Out of memory.\n");
exit(1);
}

pmem_write(&(qNew->iNode), &iNode, sizeof(int));
pmem_write(&(qNew->iDist), &iDist, sizeof(int));
pmem_write(&(qNew->iPrev), &iPrev, sizeof(int));
pmem_write(&(qNew->qNext), &NULL_INT, sizeof(int*));

if (!qLast) 
{
qHead = qNew;
}
else
{
long long next;
pmem_read(&(qLast->qNext), &next, sizeof(int*));
while (qLast->qNext)  {
pmem_read(&(qLast->qNext), &next, sizeof(int*));
qLast = next;

}

pmem_write(&(qLast->qNext), &qNew, sizeof(int*));
}
g_qCount++;
}


void dequeue (int *piNode, int *piDist, int *piPrev)
{
QITEM *qKill = qHead;

if (qHead)
{
pmem_read(&(qHead->iNode), piNode, sizeof(int));
pmem_read(&(qHead->iDist), piDist, sizeof(int));
pmem_read(&(qHead->iPrev), piPrev, sizeof(int));
pmem_read(&(qHead->qNext), &qHead, sizeof(int*));
free(qKill);
g_qCount--;
}
}

int qcount (void)
{
return(g_qCount);
}


int dijkstra(int chStart, int chEnd) 
{



for (ch = 0; ch < NUM_NODES; ch++)
{
pmem_write(&(rgnNodes[ch].iDist), &NONE_INT, sizeof(int));
pmem_write(&(rgnNodes[ch].iPrev), &NONE_INT, sizeof(int));
}

if (chStart == chEnd) 
{
printf("Shortest path is 0 in cost. Just stay where you are.\n");
}
else
{
pmem_write(&(rgnNodes[chStart].iDist), &NULL_INT, sizeof(int*));
pmem_write(&(rgnNodes[chStart].iPrev), &NONE_INT, sizeof(int)); 
enqueue (chStart, 0, NONE);

while (qcount() > 0)
{
dequeue (&iNode, &iDist, &iPrev);
for (i = 0; i < NUM_NODES; i++)
{
pmem_read(&(AdjMatrix[iNode][i]), &iCost, sizeof(int));
if ((iCost) != NONE)
{
int a;
pmem_read(&(rgnNodes[i].iDist), &a, sizeof(int));
if ((NONE == a) || 
(a > (iCost + iDist)))
{
int t = iDist + iCost;
pmem_write(&(rgnNodes[i].iDist), &t, sizeof(int));
pmem_write(&(rgnNodes[i].iPrev), &iNode, sizeof(int));
enqueue (i, iDist + iCost, iNode);
}
}
}
}


printf("Shortest path is %d in cost. ", rgnNodes[chEnd].iDist);
printf("Path is: ");
print_path(rgnNodes, chEnd);
printf("\n");
}
}


int main(int argc, char *argv[]) {

const char *device = "/dev/dax0.0";
const size_t block_size = 4;
int fd = open(device, O_RDWR);
if (fd < 0) {
printf("NVM device open failed.\n");
return -1;
}

void *m1 = mmap(NULL, sizeof(int)*NUM_NODES*NUM_NODES, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
void *m2 = mmap(NULL, sizeof(NODE)*NUM_NODES, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
AdjMatrix = (int**)m1;
rgnNodes = (NODE*)m2;

struct timespec start, end;
long long int start_ns, end_ns, delta_ns;
clock_gettime(CLOCK_MONOTONIC, &start);
start_ns = start.tv_sec * 1000000000LL + start.tv_nsec;

int i,j,k;
FILE *fp;

if (argc<2) {
fprintf(stderr, "Usage: dijkstra <filename>\n");
fprintf(stderr, "Only supports matrix size is #define'd.\n");
}

/* open the adjacency matrix file */
fp = fopen (argv[1],"r");

/* make a fully connected matrix */
for (i=0;i<NUM_NODES;i++) {
for (j=0;j<NUM_NODES;j++) {
/* make it more sparce */
fscanf(fp,"%d",&k);
pmem_write(&(AdjMatrix[i][j]), &k, sizeof(k));
}
}

/* finds 10 shortest paths between nodes */
for (i=0,j=NUM_NODES/2;i<20;i++,j++) {
j=j%NUM_NODES;
printf("%d\n", j);
dijkstra(i,j);
}

clock_gettime(CLOCK_MONOTONIC, &end);
end_ns = end.tv_sec * 1000000000LL + end.tv_nsec;
delta_ns = end_ns - start_ns;
printf("Time is %lldns\n", delta_ns);


munmap(m1, sizeof(int)*NUM_NODES*NUM_NODES);
munmap(m2, sizeof(NODE*)*NUM_NODES);
close(fd);

exit(0);
}
