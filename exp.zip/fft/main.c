#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>


int main(int argc, char *argv[]) {
	unsigned MAXSIZE;
	unsigned MAXWAVES;
	unsigned i,j;
	float *RealIn;
	float *ImagIn;
	float *RealOut;
	float *ImagOut;
	float *coeff;
	float *amp;
	int invfft=0;

	if (argc<3)
	{
		printf("Usage: fft <waves> <length> -i\n");
		printf("-i performs an inverse fft\n");
		printf("make <waves> random sinusoids");
		printf("<length> is the number of samples\n");
		exit(-1);
	}
	else if (argc==4)
		invfft = !strncmp(argv[3],"-i",2);
	MAXSIZE=atoi(argv[2]);
	MAXWAVES=atoi(argv[1]);
		
 srand(1);
 
 const char *device = "/dev/dax0.0";
const size_t block_size = 4;
int fd = open(device, O_RDWR);
if (fd < 0) {
printf("NVM device open failed.\n");
return -1;
}

void *m1 = mmap(NULL, 1*1024*1024*1024, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);


struct timespec start, end;
long long int start_ns, end_ns, delta_ns;
clock_gettime(CLOCK_MONOTONIC, &start);
start_ns = start.tv_sec * 1000000000LL + start.tv_nsec;

 // RealIn=(float*)malloc(sizeof(float)*MAXSIZE);
 // ImagIn=(float*)malloc(sizeof(float)*MAXSIZE);
 // RealOut=(float*)malloc(sizeof(float)*MAXSIZE);
 // ImagOut=(float*)malloc(sizeof(float)*MAXSIZE);
 // coeff=(float*)malloc(sizeof(float)*MAXWAVES);
 // amp=(float*)malloc(sizeof(float)*MAXWAVES);
 RealIn = (float*)((char*)m1);
 ImagIn = (float*)((char*)m1 + sizeof(float)*MAXSIZE);
 RealOut = (float*)((char*)m1 + 2*sizeof(float)*MAXSIZE);
  ImagOut = (float*)((char*)m1 + 3*sizeof(float)*MAXSIZE);
   coeff = (float*)((char*)m1 + 4*sizeof(float)*MAXSIZE);
    amp = (float*)((char*)m1 + 5*sizeof(float)*MAXSIZE);
 /* Makes MAXWAVES waves of random amplitude and period */
	for(i=0;i<MAXWAVES;i++) 
	{
		coeff[i] = rand()%1000;
		amp[i] = rand()%1000;
	}
 for(i=0;i<MAXSIZE;i++) 
 {
   /*   RealIn[i]=rand();*/
	 RealIn[i]=0;
	 for(j=0;j<MAXWAVES;j++) 
	 {
		 /* randomly select sin or cos */
		 if (rand()%2)
		 {
		 		RealIn[i]+=coeff[j]*cos(amp[j]*i);
			}
		 else
		 {
		 	RealIn[i]+=coeff[j]*sin(amp[j]*i);
		 }
  	 ImagIn[i]=0;
	 }
 }

 /* regular*/
 fft_float (MAXSIZE,invfft,RealIn,ImagIn,RealOut,ImagOut);
 
 printf("RealOut:\n");
 for (i=0;i<MAXSIZE;i++)
   printf("%f \t", RealOut[i]);
 printf("\n");

printf("ImagOut:\n");
 for (i=0;i<MAXSIZE;i++)
   printf("%f \t", ImagOut[i]);
   printf("\n");

 
 clock_gettime(CLOCK_MONOTONIC, &end);
end_ns = end.tv_sec * 1000000000LL + end.tv_nsec;
	delta_ns = end_ns - start_ns;
	printf("Time is %lldns\n", delta_ns);


munmap(m1, 1*1024*1024*1024);
close(fd);
 
 exit(0);


}
