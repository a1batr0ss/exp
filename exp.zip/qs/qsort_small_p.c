#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>

#define UNLIMIT
#define MAXARRAY 60000 /* this number, if too large, will cause a seg. fault!! */

struct myStringStruct {
  char qstring[128];
};

int compare(const void *elem1, const void *elem2)
{
  int result;
  
  result = strcmp((*((struct myStringStruct *)elem1)).qstring, (*((struct myStringStruct *)elem2)).qstring);

  return (result < 0) ? 1 : ((result == 0) ? 0 : -1);
}


int main(int argc, char *argv[]) {

  // struct myStringStruct array[MAXARRAY];

  const char *device = "/dev/dax0.0";
  const size_t block_size = 4;
  int fd = open(device, O_RDWR);
  if (fd < 0) {
    printf("NVM device open failed.\n");
    return -1;
  }

  void *m1 = mmap(NULL, 1*1024*1024*1024, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
  struct myStringStruct *array = (struct myStringStruct*)m1;
  FILE *fp;
  int i,count=0;
  
  if (argc<2) {
    fprintf(stderr,"Usage: qsort_small <file>\n");
    exit(-1);
  }
  else {
    fp = fopen(argv[1],"r");
    
    while((fscanf(fp, "%s", &array[count].qstring) == 1) && (count < MAXARRAY)) {
	 count++;
    }
  }

  struct timespec start, end;
  long long int start_ns, end_ns, delta_ns;
  clock_gettime(CLOCK_MONOTONIC, &start);
  start_ns = start.tv_sec * 1000000000LL + start.tv_nsec;


  printf("\nSorting %d elements.\n\n",count);
  qsort(array,count,sizeof(struct myStringStruct),compare);
  
  for(i=0;i<count;i++)
    printf("%s\n", array[i].qstring);

  clock_gettime(CLOCK_MONOTONIC, &end);
  end_ns = end.tv_sec * 1000000000LL + end.tv_nsec;
  delta_ns = end_ns - start_ns;
  printf("Time is %lldns\n", delta_ns);

  munmap(m1, 1*1024*1024);
  close(fd);

  return 0;
}
